import asyncio
from fastapi import FastAPI, UploadFile, File, BackgroundTasks, WebSocket, WebSocketDisconnect, Form  # {{ edit: Import Form }}
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import time
import io
import uuid  # {{ edit: Import uuid for unique task_id }}
from typing import Dict

app = FastAPI()

# Allow CORS for frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for progress and files
progress_store: Dict[str, Dict] = {}
result_store: Dict[str, io.BytesIO] = {}
active_connections: Dict[str, WebSocket] = {}

@app.post("/api/upload")
async def upload_files(
    pptxFile: UploadFile = File(...),
    pdfFile: UploadFile = File(...),
    selectedModel: str = Form(...),
    numberOfPages: int = Form(...)
):
    task_id = str(uuid.uuid4())
    progress_store[task_id] = {
        "progress": 0,
        "selectedModel": selectedModel,
        "numberOfPages": numberOfPages
    }
    # Simulate saving files (skipped)
    # You can add file saving logic here if needed

    # Start generation immediately after upload
    asyncio.create_task(simulate_generation(task_id))
    
    return {"task_id": task_id}

# Remove the /api/generate endpoint
# {{ edit: Remove the /api/generate endpoint }}

async def simulate_generation(task_id: str):
    selectedModel = progress_store[task_id]["selectedModel"]
    numberOfPages = progress_store[task_id]["numberOfPages"]
    for progress in range(0, 101, 10):
        progress_store[task_id]["progress"] = progress
        if task_id in active_connections:
            websocket = active_connections[task_id]
            await send_progress(websocket, progress)
        await asyncio.sleep(1)
    # Simulate result file
    result_store[task_id] = io.BytesIO(b"Fake PPTX content")

async def send_progress(websocket: WebSocket, progress: int):
    await websocket.send_json({"progress": progress, "status": f"Progress: {progress}%"})  # {{ edit: Send progress and status }}

@app.websocket("/ws/{task_id}")
async def websocket_endpoint(websocket: WebSocket, task_id: str):
    await websocket.accept()
    active_connections[task_id] = websocket
    try:
        while True:
            data = await websocket.receive_text()  # Keep the connection open
    except WebSocketDisconnect:
        del active_connections[task_id]

@app.get("/api/download")
def download(task_id: str):
    file = result_store.get(task_id)
    if file:
        file.seek(0)
        return StreamingResponse(
            file,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition": "attachment; filename=output.pptx"}
        )
    return {"error": "File not found"}

@app.get("/")
def hello():
    return {"message": "Hello, World!"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
