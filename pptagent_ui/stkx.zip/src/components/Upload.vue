<template>
  <!-- Upload form -->
  <div class="upload-container">
    <div class="upload-options">
      <!-- Row 1: Upload Buttons -->
      <div class="upload-buttons">
        <div class="upload-section">
          <label for="pptx-upload" class="upload-label">
            Upload PPTX
            <span v-if="pptxFile" class="uploaded-symbol">✔️</span> <!-- {{ edit: Add checkmark symbol when PPTX is uploaded }} -->
          </label>
          <input type="file" id="pptx-upload" @change="handleFileUpload($event, 'pptx')"
            accept=".pptx" />
        </div>
        <div class="upload-section">
          <label for="pdf-upload" class="upload-label">
            Upload PDF
            <span v-if="pdfFile" class="uploaded-symbol">✔️</span> <!-- {{ edit: Add checkmark symbol when PDF is uploaded }} -->
          </label>
          <input type="file" id="pdf-upload" @change="handleFileUpload($event, 'pdf')"
            accept=".pdf" />
        </div>
      </div>

      <!-- Row 2: Selectors -->
      <div class="selectors">
        <div class="model-selection">
          <select v-model="selectedModel">
            <option v-for="model in models" :key="model" :value="model">{{ model }}</option>
          </select>
        </div>
        <div class="pages-selection">
          <select v-model="selectedPages">
            <option v-for="page in pagesOptions" :key="page" :value="page">{{ page }} 页</option>
          </select>
        </div>
      </div>
    </div>
    <button @click="goToGenerate" class="next-button">Next</button> <!-- Updated click handler -->
  </div>
</template>

<script>
export default {
  name: 'UploadComponent',
  data() {
    return {
      pptxFile: null,  // {{ edit: Change from pptxFiles to single pptxFile }}
      pdfFile: null,   // {{ edit: Change from pdfFiles to single pdfFile }}
      selectedModel: 'Qwen2-72B-Instruct',
      models: ['Qwen2-72B-Instruct'],
      selectedPages: 8,
      pagesOptions: Array.from({ length: 24 }, (_, i) => i + 8)
    }
  },
  methods: {
    handleFileUpload(event, fileType) {
      console.log("Handling file upload for:", fileType)
      const file = event.target.files[0]
      if (fileType === 'pptx') {
        this.pptxFile = file  // {{ edit: Assign single pptxFile }}
      } else if (fileType === 'pdf') {
        this.pdfFile = file  // {{ edit: Assign single pdfFile }}
      }
    },
    async goToGenerate() { // Renamed method from goToDoc to goToGenerate
      // Initiate upload on backend
      const formData = new FormData()
      formData.append('pptxFile', this.pptxFile)
      formData.append('pdfFile', this.pdfFile)
      formData.append('numberOfPages', this.selectedPages)
      formData.append('selectedModel', this.selectedModel)

      try {
        const uploadResponse = await this.$axios.post('/api/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        const taskId = uploadResponse.data.task_id

        // Navigate to Generate component with taskId
        this.$router.push({ name: 'Generate', params: { taskId } })
      } catch (error) {
        console.error("Upload error:", error)
        this.statusMessage = 'Failed to upload files.'
      }
    }
  }
}
</script>

<style scoped>
.upload-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background-color: #f0f8ff;
  /* Light background for better contrast */
  padding: 40px;
  box-sizing: border-box;
}

.upload-options {
  display: flex;
  flex-direction: column;
  gap: 30px;
  /* Increased gap between rows */
  width: 100%;
  max-width: 600px;
}

.upload-buttons,
.selectors {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  /* Spacing between items in the row */
}

.upload-section,
.model-selection,
.pages-selection {
  flex: 1;
  /* Ensure equal width */
  display: flex;
  flex-direction: column;
  align-items: center;
}

.upload-label {
  position: relative;
  background-color: #42b983;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  text-align: center;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.3s;
}

.upload-label:hover {
  background-color: #369870;
}

.upload-section input[type="file"] {
  display: none;
}

.model-selection select,
.pages-selection select {
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  width: 100%;
  height: 40px;
  box-sizing: border-box;
  font-size: 16px;
}

.next-button {
  background-color: #35495e;
  color: white;
  padding: 12px 0;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  width: 220px;
  margin-top: 30px;
  font-size: 20px;
  font-weight: 700;
  transition: background-color 0.3s, transform 0.2s;
}

.next-button:hover {
  background-color: #2c3e50;
  transform: scale(1.05);
}

.uploaded-symbol {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: green;
  font-size: 18px;
}

@media (max-width: 600px) {
  .upload-buttons,
  .selectors {
    flex-direction: column;
    gap: 35px;
  }

  .next-button {
    width: 100%;
  }
}
</style>