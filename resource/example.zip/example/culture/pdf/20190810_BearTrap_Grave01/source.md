# 20190810_Beartrap_Grave01

Processing **Report**
27 Oktober **2021**

![0_image_0.png](0_image_0.png)

# Survey Data

![1_Image_1.Png](1_Image_1.Png)

Fig. 1. Camera locations and image overlap.

Number of images: 641 Camera stations: 639

| Camera    | Model       | Resolution   |      | Focal Length   | Pixel Size   | Precalibrated   |    |    |    |    |    |
|-----------|-------------|--------------|------|----------------|--------------|-----------------|----|----|----|----|----|
| ILCE-6000 | (16mm) 6000 | x            | 4000 | 16             | mm           |                 | 4  | x  | 4  | μm | No |

| Tie          | points:   | 607,327   |     |
|--------------|-----------|-----------|-----|
| Projections: | 1,751,346 |           |     |
| Reprojection | error:    | 0.358     | pix |

Table 1. Cameras.

1

![1_image_0.png](1_image_0.png) 2 3 4 5 6 7 8 9 > 9

# Camera Calibration

![2_image_0.png](2_image_0.png)

Fig. 2. Image residuals for ILCE-6000 (16mm).

ILCE-6000 **(16mm)** 641 images

| Type        |        | Resolution   |    | Focal Length   | Pixel Size   |    |    |    |    |    |
|-------------|--------|--------------|----|----------------|--------------|----|----|----|----|----|
| Frame       |        | 6000         | x  | 4000           | 16           | mm | 4  | x  | 4  | μm |
| F:          | 4083.8 |              |    |                |              |    |    |    |    |    |
| Cx:         | B1:    |              |    |                |              |    |    |    |    |    |
| -63.3208    |        | -0.111849    |    |                |              |    |    |    |    |    |
| Cy:         | B2:    |              |    |                |              |    |    |    |    |    |
| -29.5147    |        | -0.405142    |    |                |              |    |    |    |    |    |
| K1:         | P1:    |              |    |                |              |    |    |    |    |    |
| -0.00558067 |        | -0.000856224 |    |                |              |    |    |    |    |    |
| K2:         | P2:    |              |    |                |              |    |    |    |    |    |
| -0.00368711 |        | 0.000202483  |    |                |              |    |    |    |    |    |
| K3:         | P3:    |              |    |                |              |    |    |    |    |    |
| 0.0153141   |        | 0            |    |                |              |    |    |    |    |    |
| K4:         | P4:    |              |    |                |              |    |    |    |    |    |
| -0.00966728 |        | 0            |    |                |              |    |    |    |    |    |

# Digital Elevation Model

![3_Image_0.Png](3_Image_0.Png)

Fig. 3. Reconstructed digital elevation model.

# Processing Parameters

| General Cameras                | 641                      |                         |
|--------------------------------|--------------------------|-------------------------|
| Aligned cameras                | 639                      |                         |
| Coordinate system              |                          | Local Coordinates (m)   |
| Rotation angles                | Yaw, Pitch, Roll         |                         |
| Point Cloud                    |                          |                         |
| Points                         | 607,327 of 3,003,225     |                         |
| RMS                            | reprojection error       | 0.119995 (0.358147 pix) |
| Max reprojection error         | 0.264431 (3.15182 pix)   |                         |
| Mean key point size            | 2.89242 pix              |                         |
| Point colors                   | 3 bands, uint8           |                         |
| Key points                     | No                       |                         |
| Average tie point multiplicity | 5.21063                  |                         |
| Alignment parameters Accuracy  | High                     |                         |
| Generic preselection           | Yes                      |                         |
| Key point limit                | 60,000                   |                         |
| Tie point limit                | 0                        |                         |
| Filter points by mask          | Yes                      |                         |
| Mask tie points                | No                       |                         |
| Adaptive camera model fitting  | No                       |                         |
| Matching time                  | 1 hours 26 minutes       |                         |
| Alignment time                 | 24 minutes 38 seconds    |                         |
| Optimization                   | parameters               |                         |
| Parameters                     | f, cx, cy, k1-k3, p1, p2 |                         |
| Adaptive camera model fitting  | Yes                      |                         |
| Optimization time              | 12 seconds               |                         |
| File size                      | 261.36 MB                |                         |
| Depth                          | Maps                     |                         |
| Count                          | 638                      |                         |
| Depth                          | maps generation          | parameters              |
| Quality                        | High                     |                         |
| Filtering mode                 | Mild                     |                         |
| Processing time                | 5 hours 1 minutes        |                         |
| Memory usage                   | 10.12 GB                 |                         |
| Software version               | 1.7.1.11797              |                         |
| File size                      | 5.06 GB                  |                         |
| Dense Point Cloud              |                          |                         |
| Points                         | 86,872,038               |                         |
| Point colors                   | 3 bands, uint8           |                         |
| Depth                          | maps generation          | parameters              |
| Quality                        | High                     |                         |
| Filtering mode                 | Mild                     |                         |
| Processing time                | 5 hours 1 minutes        |                         |
| Memory usage                   | 10.12 GB                 |                         |
| Dense cloud                    | generation               | parameters              |
| Processing time                | 3 hours 30 minutes       |                         |
| Memory usage                   | 26.69 GB                 |                         |
| Software version               | 1.7.1.11797              |                         |
| File size                      | 2.54 GB                  |                         |
| Model                          |                          |                         |

| Faces                   | 25,634,607                     |                            |     |    |
|-------------------------|--------------------------------|----------------------------|-----|----|
| Vertices                | 12,825,488                     |                            |     |    |
| Vertex colors           | 3 bands, uint8                 |                            |     |    |
| Texture                 | 4,096 x 4,096, 4 bands, uint8  |                            |     |    |
| Depth                   | maps generation                | parameters                 |     |    |
| Quality                 | High                           |                            |     |    |
| Filtering mode          | Mild                           |                            |     |    |
| Processing time         | 5 hours 1 minutes              |                            |     |    |
| Memory usage            | 10.12 GB                       |                            |     |    |
| Reconstruction          | parameters                     |                            |     |    |
| Surface type            | Arbitrary                      |                            |     |    |
| Source data             | Depth maps                     |                            |     |    |
| Interpolation           | Enabled                        |                            |     |    |
| Strict volumetric masks | No                             |                            |     |    |
| Processing time         | 1 hours 31 minutes             |                            |     |    |
| Memory usage            | 11.90 GB                       |                            |     |    |
| Texturing               | parameters                     |                            |     |    |
| Mapping mode            | Generic                        |                            |     |    |
| Blending mode           | Mosaic                         |                            |     |    |
| Texture size            | 4,096                          |                            |     |    |
| Enable hole filling     | Yes                            |                            |     |    |
| Enable ghosting filter  | Yes                            |                            |     |    |
| UV                      | mapping time                   | 6 minutes 15 seconds       |     |    |
| UV                      | mapping memory usage           | 5.64 GB                    |     |    |
| Blending time           | 1 hours 3 minutes              |                            |     |    |
| Blending memory usage   | 9.19 GB                        |                            |     |    |
| Software version        | 1.7.1.11797                    |                            |     |    |
| File size               | 1.09 GB                        |                            |     |    |
| System                  |                                |                            |     |    |
| Software name           | Agisoft Metashape Professional |                            |     |    |
| Software version        | 1.7.1 build 11797              |                            |     |    |
| OS                      |                                | Linux 64 bit               |     |    |
| RAM                     |                                | 125.62 GB                  |     |    |
| CPU                     |                                | Intel(R) Core(TM) i7-9800X | CPU | @  |
|                         | 3.80GHz                        |                            |     |    |
| GPU(s)                  | Quadro P1000                   |                            |     |    |
